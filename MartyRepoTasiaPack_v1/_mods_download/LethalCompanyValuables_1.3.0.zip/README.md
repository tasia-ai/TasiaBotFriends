# LethalCompanyValuables

[![Thunderstore Version](https://img.shields.io/thunderstore/v/Zehs/LethalCompanyValuables?style=for-the-badge&logo=thunderstore&logoColor=white)](https://thunderstore.io/c/repo/p/Zehs/LethalCompanyValuables)
[![Thunderstore Downloads](https://img.shields.io/thunderstore/dt/Zehs/LethalCompanyValuables?style=for-the-badge&logo=thunderstore&logoColor=white)](https://thunderstore.io/c/repo/p/Zehs/LethalCompanyValuables)

**Adds 30 scrap items from Lethal Company as valuables. Some valuables have special interactions.**

**<ins>Who needs this mod installed for it to work?</ins> Everyone!**

## Valuables
- **Airhorn** *(Special interactions)*
- **Apparatus** *(Special interactions)*
- Big Bolt
- Bottles
- **Brass Bell** *(Special interactions)*
- **Cash Register** *(Special interactions)*
- Chemical Jug
- **Clown Horn** *(Special interactions)*
- Fancy Lamp
- Flask
- **Gift Box** *(Special interactions)*
- Gold Bar
- Golden Cup
- Hair Brush
- **Hairdryer** *(Special interactions)*
- Jar Of Pickles
- Large Axle
- Painting
- Magnifying Glass
- Metal Sheet
- Old Phone
- Perfume Bottle
- Plastic Fish
- Red Soda
- Rubber Ducky
- Tea Kettle
- **Teeth** *(Special interactions)*
- Toy Cube
- **Toy Robot** *(Special interactions)*
- V-Type Engine

## Developer Contact

**Report bugs, suggest features, or provide feedback:**

| **Discord Server** | **Forum** | **Post** |  
|--------------------|-----------|----------|  
| [R.E.P.O. Modding Server](https://discord.com/invite/vPJtKhYAFe) | `#released-mods` | [LethalCompanyValuables](https://discord.com/channels/1344557689979670578/1347843014269079605) |

https://solo.to/crithaxxog

<a href="https://ko-fi.com/zehsteam" target="_blank">
<img src="https://storage.ko-fi.com/cdn/brandasset/v2/support_me_on_kofi_dark.png" alt="Ko-Fi" width="200px"/>
</a>
