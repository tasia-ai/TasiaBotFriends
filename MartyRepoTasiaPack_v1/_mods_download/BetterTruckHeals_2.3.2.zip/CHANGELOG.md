# Changelog

## [2.3.2] (2026-05-7)

- Readjusted code for the Cosmetic Update!

- Removed REPOConfig as a dependency

## [2.2.2] (2025-07-1)

- Added support for The Museum Update!

- Bug Report/Feedback form opened

