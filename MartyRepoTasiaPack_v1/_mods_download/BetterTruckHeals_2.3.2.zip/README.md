**Fully configurable heal amount with REPOConfig!**

**Now supports percentage or flat number values!**

Increases Heal amount to 50 instead of default 25!

Submit any bugs or feedback here: https://forms.gle/bR7DnuVYz5FvKDDp8 

Huge hugs and thanks to my personal in house tester! (Which is a random dwarf)

All love <3

-Lazarus