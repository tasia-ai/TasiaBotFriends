# BotFriends v3.6.0
Spawn a squad of colorful bot friends that follow you around, grab nearby valuables, and haul them to the extractor like loyal little loot goblins. Singleplayer only. WIP.

![BotFriends Preview 1](https://i.ibb.co/0yh6zK4d/Repo-2026-04-25-23-24-24-20-1.gif)

---

## Singleplayer Only
BotFriends works exclusively in singleplayer.  
The mod includes built-in checks to prevent bot spawning in multiplayer, protecting lobbies.

---

## Important Note
You may see NavMesh-related warnings in the log. These do not matter and can be safely ignored.

---

## What the mod does
BotFriends spawns one or a small crew of player-avatar bot friends that:

- Follow you around or wander near you, depending on your config.
- Scan for nearby valuables in a configurable radius and pick them up.
- Carry valuables toward extraction using the game's real extraction logic.
- Activate extractors. It may not be instant, but they will do it.

### Extractor behavior
- Bots will place valuables into the nearest active extractor.
- If no extractor is active, they carry loot into the next extractor and wait there for activation.
- If you activate a different extractor instead, bots will change targets automatically.
- Once all extraction points are completed, they head to the truck area.

Bots sometimes seem to have their own personalities:
- One that listens
- One that wanders off
- One that feels cursed
- One you learn to hate

Not intentional, but funny, so it stays.

---

Best experience: install RepoConfig so you can tweak all BotFriends settings from the in-game Mods menu instead of editing the config file manually.  
Multiplayer is blocked for safety.

---

## Config options
`BepInEx/config/Empress.BotFriends.cfg`

### Bots
- ExtraBots - How many friends spawn (0-5)
- BotSpeed - NavMesh move speed
- FollowPlayer - True = they follow, False = they wander (defaults to False)
- Enable Physics Ragdoll - True/False
- Ragdoll Impact Threshold - How easily they topple
- Ragdoll Recovery Time - How fast they get back up

### Carry / Valuables
- FetchValuables - Enables item pickup
- PickupSearchRadius - How far bots scan for loot
- ExtractorStopDistance - How close a bot tries to deliver items
- HoldOffsetY - Visual hold height

---

## Credits
**Coded by:**  
- Omniscye / Empress
- Discord server for support or bug reports: https://discord.gg/WZ6fWG4v3u

## Changelog 3.5.0
- Fixed light issue

**Extra fix help by:**  
- OrigamiCoder

**Bot name permissions:**  
- s1ckboy  
- Zehs / CritHaxXoG  
- Goat  
- 753  
- Impboy  
- Swaggies  
- Sizzlium  
- Jettcodey  
- Bocon  
- Friendly  
- gaymer  
- Endershade  
- 1A3  
- BLOKBUST  
- Doppelclick  
- Adalade Kasner  
- Skript

---

## License and third party notes
- This Thunderstore package includes binaries from 80speak which is licensed under GPL 3.0
- Because 80speak is included, this mod package is distributed under GPL 3.0
- 80speak source and license: https://github.com/connornishijima/80speak/tree/master
- The GitHub repo for this mod contains source code only and does not contain third party binaries

Have fun.

"You all exist forever as small chaotic player-avatar creatures. Enjoy"

---

## Update 3.6.0
- Bots can use most cosmetics
- Fixed issue with bots showing floating parts

## Update 3.5.0
- Updated for REPO 4.x

### Update 2.0.0
- The bots are now player avatars!

### Update 1.3.0
- Bots can now talk.
- They can say what valuables they pick up and also chat with each other.
- Added RepoConfig as a dependency so it installs with this mod.
- You will have a Mods button to edit configs at the main menu.
- They may talk in the main menu a bit if you toggle it on. This is a feature. LOL

### Update 1.2.1
- Ragdoll mode has been added.
- Not perfect, but it is funny.
- Enabled by default.

### Update 1.1.0
- Bots now properly wander the entire level by default if Follow Player is off.
- Follow Player is OFF by default now.
- Bots will now activate extractors.
- It may not be instant, but they will do it.
- Removed unnecessary Photon call.
